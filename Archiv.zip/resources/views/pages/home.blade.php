@extends('layouts.main')

@section('content')
    @include('components.hero')
    @include('components.features')
    @include('components.home-content')
    @include('components.social-media')
    @include ('components.footer')
@endsection
