<?php $__env->startSection('content'); ?>
<div class="classes">
  <div class="classes__hero">
      <img loading="lazy" class="classes__image" src="<?php echo e($courseSetting->class_image); ?>" alt="">
      <h1 class="classes__title"><?php echo e($courseSetting->class_heading); ?></h1>
    </div>
    <div class="container">
      <div class="row classes__content">
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
          <div class="card classes__card">
          <img loading="lazy" src="<?php echo e($course->course_img); ?>" class="card-img-top" alt="...">
          <div class="card-body">
          <h5 class="card-title"><?php echo e($course->course_title); ?></h5>
          <p class="card-text"><?php echo e($course->course_p); ?></p>
          <a href="/login" class="btn btn-outline-dark"><?php echo e($course->course_link); ?></a>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
</div>
    <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/benjaminsparwasser/Desktop/gymapp/resources/views/pages/classes.blade.php ENDPATH**/ ?>