<?php $__env->startSection('content'); ?>
  <div class="membership">
    <div class="membership__hero">
      <img class="membership__image" src="<?php echo e($membership1->membership_img); ?>" alt="">
      <h1 class="membership__title"><?php echo e($membership1->membership_heading); ?></h1>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="membership__offer">
            <div class="membership__offer--pro">
              <h1><?php echo e($membership2->membership_plan); ?></h1>
            </div>
            
            <h3>Billed Annually</h3>
            <h4><?php echo e($membership2->membership_price); ?></h4>
            <div class="membership__lists">
              <ul class="membership__benefits">
                <?php $__currentLoopData = $benefitsOne; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $benefit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><i class="fa-solid <?php echo e($benefit->icon); ?>"></i> <?php echo e($benefit->benefit); ?></i></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
              
            </div>

            <a href="/login" class="btn btn-outline-danger mb-5 membership__btn"><?php echo e($membership2->membership_btn); ?></a>
            
          </div>
        </div>
        <div class="col-md-6">
          <div class="membership__offer">
            <div class="membership__offer--basic">
              <h1><?php echo e($membership3->membership_plan); ?></h1>
            </div>
            
            <h3>Billed Monthly</h3>
            <h4><?php echo e($membership3->membership_price); ?></h4>
            <div class="membership__lists">
              <ul class="membership__benefits">
                <?php $__currentLoopData = $benefitsTwo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $benefit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><i class="fa-solid <?php echo e($benefit->icon); ?>"></i> <?php echo e($benefit->benefit); ?></i></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              

            </ul>
              
            </div>

            <a href="#" class="btn btn-outline-danger mb-5 membership__btn"><?php echo e($membership2->membership_btn); ?></a>
            
          </div>
        </div>
        </div>
        <div class="membership__info">
          <h4><?php echo e($membership1->membership_description); ?></h4>
        </div>
      </div>
    </div>
  </div>
  <?php echo $__env->make('components.social-media', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/benjaminsparwasser/Desktop/gymapp/resources/views/pages/memberships.blade.php ENDPATH**/ ?>