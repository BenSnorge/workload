<div class="home-content bg-light">
  <div class="container ">
    <div class="home-content__description">
      <div class="row justify-content-md-center">
        <div class="col-lg-8 col-lg-auto d-flex flex-column justify-content-center  align-items-center">
          <div class="home-content__title">
            <h1><?php echo e($content1->content_heading); ?></h1>
          </div>
          <p><?php echo e($content1->content_p); ?></p>
        </div>
      </div>
      
    </div>
      <div class="row ">
        <div class="col-lg-6">
          <div class="home-content__box d-flex flex-column justify-content-center  align-items-center">
            <h3><?php echo e($content2->content_heading); ?></h3>
            <p><?php echo e($content2->content_p); ?></p>
            <a class="btn btn-outline-dark" href="/memberships"><?php echo e($content2->content_button); ?></a>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="home-content__box">
          <img loading="lazy" src="<?php echo e($content2->content_image); ?>" class="col-12" alt="">
          </div>
        </div>
      </div>
      <div class="home-content__section">
        <div class="row">
        <div class="col-lg-6">
          <div class="home-content__box">
          <img loading="lazy" src="<?php echo e($content3->content_image); ?>" class="col-12" alt="">
          </div>
        </div>
        <div class="col-lg-6">
          <div class="home-content__box d-flex flex-column justify-content-center  align-items-center">
            <h3><?php echo e($content3->content_heading); ?></h3>
            <p><?php echo e($content3->content_p); ?></p>
            <a href="/trainers" class="btn btn-outline-dark"><?php echo e($content3->content_button); ?></a>
          </div>
        </div>
      </div>
      </div>
      <div class="home-content__section">

      
      <div class="row ">
        <div class="col-lg-6">
          <div class="home-content__box d-flex flex-column justify-content-center  align-items-center">
            <h3><?php echo e($content4->content_heading); ?></h3>
            <p><?php echo e($content4->content_p); ?></p>
            <a href="/nutrition" class="btn btn-outline-dark"><?php echo e($content4->content_button); ?></a>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="home-content__box">
          <img loading="lazy" src="<?php echo e($content4->content_image); ?>" class="col-12" alt="">
          </div>
        </div>
      </div>
      </div>
      <div class="row ">
        <div class="col-lg-6">
          <div class="home-content__box">
          <img loading="lazy" src="<?php echo e($content5->content_image); ?>" class="col-12" alt="">
          </div>
        </div>
        <div class="col-lg-6">
          <div class="home-content__box d-flex flex-column justify-content-center  align-items-center">
            <h3><?php echo e($content5->content_heading); ?></h3>
            <p><?php echo e($content5->content_p); ?></p>
            <a href="/classes" class="btn btn-outline-dark"><?php echo e($content5->content_button); ?></a>
          </div>
        </div>
      </div>
      <div class="home-content__description">
      <div class="row justify-content-md-center">
        <div class="col-lg-8 col-lg-auto d-flex flex-column justify-content-center  align-items-center">
          
        </div>
      </div>
      
    </div>
    </div>
</div>

<?php /**PATH /Users/benjaminsparwasser/Desktop/gymapp/resources/views/components/home-content.blade.php ENDPATH**/ ?>