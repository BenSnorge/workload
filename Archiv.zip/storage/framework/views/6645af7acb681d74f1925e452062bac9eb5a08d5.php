<?php $__env->startSection('content'); ?>
<h1>Welcome <?php echo e(Auth::user()->name); ?></h1>


<div class="container">
      <div class="row classes__content">
        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6">
          <div class="card classes__card border-dark">
          <img loading="lazy" src="" class="card-img-top" alt="">
          <div class="card-body ">
          <h5 class="card-title">Subscribe to the <?php echo e($plan->name); ?></h5>
          <p class="card-text">
          $<?php echo e($plan->price); ?>

          </p>
          <?php if (\Illuminate\Support\Facades\Blade::check('subscribedToProduct', $user, $plan->stripeProductId(), $plan->stripeName())): ?>

          <h4 class="h4">You are currently subscribed to this plan.</h4>

          <?php if (\Illuminate\Support\Facades\Blade::check('onGracePeriod', $plan->stripeName())): ?>
          <h4>Your subscription will end on <?php echo e($user->subscription($plan->stripeName())->ends_at->format('d F Y')); ?></h4>

          
          <a class="btn btn-primary" href="<?php echo e(route('subscriptions.update', $plan->stripeName())); ?>">Resume Subscription</a>


          <?php else: ?>
           
          <a class="btn btn-primary" href="<?php echo e(route('subscriptions.destroy', $plan->stripeName())); ?>">Cancel Subscription</a>
          
          <?php endif; ?>
          <?php else: ?>
          <a href="/pages<?php echo e($plan->abbreviation); ?>" class="btn btn-outline-dark">Subscribe</a>
          <?php endif; ?>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
        
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/benjaminsparwasser/Desktop/gymapp/resources/views/user-dashboard/welcome.blade.php ENDPATH**/ ?>