<?php $__env->startSection('content'); ?>
<div class="row">
  <!-- ============================================================== -->
  <!-- basic table -->
  <!-- ============================================================== -->
  <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
    <div class="card">
      <h5 class="card-header">All Trainers</h5>
      <div class="card-body">
        <table class="table">
          <thead>
            <tr>
              <th scope="col">Id</th>
              <th scope="col">Title</th>
              <th scope="col">Edit</th>
              <th scope="col">Delete</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($trainer->id); ?></th>
              <td><?php echo e($trainer->trainer_name); ?></td>
              <td><a class="text-black" href="/admin/all-trainers/<?php echo e($trainer->id); ?>/edit-trainer"><i
                    class="far fa-edit"></i></a></td>
              <td>

                <a class="text-black" href="#" onclick="event.preventDefault();
                        confirm('Are you sure you want to delete?');
                                document.getElementById('delete-trainer<?php echo e($trainer->id); ?>').submit();"><i
                    class="far fa-trash-alt">
                  </i>
                </a>
                <form id="delete-course<?php echo e($trainer->id); ?>" action="/admin/all-trainers/<?php echo e($trainer->id); ?>/delete"
                  method="POST" class="d-none">
                  <?php echo method_field('DELETE'); ?>
                  <?php echo csrf_field(); ?>
                </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/benjaminsparwasser/Desktop/gymapp/resources/views/admin/all-trainers.blade.php ENDPATH**/ ?>