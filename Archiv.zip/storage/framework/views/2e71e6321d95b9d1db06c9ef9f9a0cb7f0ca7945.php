<?php $__env->startSection('content'); ?>
  <div class="container d-flex justify-content-center  align-items-center flex-column h-100">
    <h1 class="">This is the Admin Dashboard</h1>
  <p>Here you can find and edit everything on your website. You can change the pictures on your home page along with the headings and </p>
  </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/benjaminsparwasser/Desktop/gymapp/resources/views/dashboard.blade.php ENDPATH**/ ?>