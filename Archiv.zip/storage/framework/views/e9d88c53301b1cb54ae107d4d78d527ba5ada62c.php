<div class="footer">
  <div class="container">
    <div class="row">
      <div class="col-md-4">
        <div class="footer__links d-flex flex-column py-5">
          <h4><?php echo e($footer->footer_header1); ?></h4>
          <a class="footer__link" href="#"><?php echo e($footer->footer_link1); ?></a>
          
        </div>
      </div>
      <div class="col-md-4">
        <div class="footer__links d-flex flex-column py-5">
          <h4><?php echo e($footer->footer_header2); ?></h4>
          <a class="footer__link" href="#"><?php echo e($footer->footer_link2); ?></a>
          <a class="footer__link" href="#"><?php echo e($footer->footer_link3); ?></a>
        </div>
      </div>
      <div class="col-md-4">
        <div class="footer__info py-5">
          <div class="footer__address">
            <h4>Address</h4>
            <h5><?php echo e($footer->footer_city); ?></h5>
            <p><?php echo e($footer->footer_street); ?></p>
            <p><?php echo e($footer->footer_zipcode); ?></p>
            <p><?php echo e($footer->footer_phone); ?></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div><?php /**PATH /Users/benjaminsparwasser/Desktop/gymapp/resources/views/components/footer.blade.php ENDPATH**/ ?>