<?php $__env->startSection('content'); ?>
<div class="row">
  <!-- ============================================================== -->
  <!-- basic table -->
  <!-- ============================================================== -->
  <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
    <div class="card">
      <h4 class="card-header">Billing</h4>
      <div class="card-body">
        <table class="table">
          <thead>
            <tr>
              <th scope="col">Date</th>
              <th scope="col">Total</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($invoice->date()->toFormattedDateString()); ?></td>
                <td><?php echo e($invoice->total()); ?></td>
                <td><a class="btn btn-success" href="<?php echo e(route('download', $invoice->id)); ?>" target="_blank">Download</a></td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/benjaminsparwasser/Desktop/gymapp/resources/views/dashboard/billing/index.blade.php ENDPATH**/ ?>