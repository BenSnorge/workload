<?php $__env->startSection('content'); ?>

<div class="trainers bg-light">
  <h1>Meet Our Team</h1>
  
  <div class="container">
    <div class="row">
    
    <?php $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6">
          <div class="card classes__card">
          <img loading="lazy" src="<?php echo e($trainer->trainer_img); ?>" class="card-img-top" alt="...">
          <div class="card-body">
          <h5 class="card-title"><?php echo e($trainer->trainer_name); ?></h5>
          <p class="card-text"><?php echo e($trainer->trainer_p); ?></p>
          <a href="/login" class="btn btn-outline-dark"><?php echo e($trainer->trainer_link); ?></a>
            </div>
          </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
  
</div>


    <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/benjaminsparwasser/Desktop/gymapp/resources/views/pages/trainers.blade.php ENDPATH**/ ?>