<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/benjaminsparwasser/Desktop/gymapp/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>