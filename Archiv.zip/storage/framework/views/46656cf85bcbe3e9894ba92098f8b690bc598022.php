<?php $__env->startSection('content'); ?>
<div class="row">
  <!-- ============================================================== -->
  <!-- basic table -->
  <!-- ============================================================== -->
  <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
    <div class="card">
      <h5 class="card-header">All Benefits For Plan One</h5>
      <div class="card-body">
        <table class="table">
          <thead>
            <tr>
              <th scope="col">Id</th>
              <th scope="col">Description</th>
              <th scope="col">Icon</th>
              <th scope="col">Edit</th>
              <th scope="col">Delete</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope="row"><?php echo e($course->id); ?></th>
              <td><?php echo e($course->course_title); ?></td>
              <td><a class="text-black" href="/admin/all-classes/<?php echo e($course->id); ?>/class-edit"><i
                    class="far fa-edit"></i></a></td>
              <td>

                <a class="text-black" href="#" onclick="event.preventDefault();
                        confirm('Are you sure you want to delete?');
                                document.getElementById('delete-course<?php echo e($course->id); ?>').submit();"><i
                    class="far fa-trash-alt">
                  </i>
                </a>
                <form id="delete-course<?php echo e($course->id); ?>" action="/admin/all-classes/<?php echo e($course->id); ?>/delete"
                  method="POST" class="d-none">
                  <?php echo method_field('DELETE'); ?>
                  <?php echo csrf_field(); ?>
                </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <a href="/admin/create-benefits-plan-one" class="btn btn-primary">Add New Benefit</a>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/benjaminsparwasser/Desktop/gymapp/resources/views/admin/membership-pro.blade.php ENDPATH**/ ?>