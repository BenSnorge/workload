<?php $__env->startSection('content'); ?>
<h1>wlcome to your dashboard</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/benjaminsparwasser/Desktop/gymapp/resources/views//user-dashboard/welcome.blade.php ENDPATH**/ ?>