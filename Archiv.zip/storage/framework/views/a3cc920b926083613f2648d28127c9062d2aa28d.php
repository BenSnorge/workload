<?php $__env->startSection('content'); ?>
  <div class="login">
   <div class="container">
    <form class="col-lg-4 mx-auto" method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>
      <?php echo csrf_field(); ?> 
      <h3 class="mb-3">Register</h3>
      <div class="mx-auto mb-3">
        <label class="form-label" for="" value="name">Name</label>
        <input class="form-control" id="fname" type="text" name="name">
      </div>
      <div class="mx-auto mb-3">
        <label class="form-label" for="" :value="__('Email')">Email</label>
        <input class="form-control" id="email" type="email" name="email">
      </div>
      
      <div class="mx-auto mb-3">
        <label class="form-label" for="password" :value="__('Password')">Password</label>
        <input id="password" class="form-control" type="password"
        name="password"
        required autocomplete="new-password" >
      </div>
      <div class="mx-auto mb-3">
        <label class="form-label" for="password_confirmation" :value="__('Confirm Password')">Confirm Password</label>
        <input id="password_confirmation" class="form-control" type="password"
        name="password_confirmation" requiredtype="password">
      </div>
  
  <button class="btn btn-primary" type="submit"><?php echo e(__('Register')); ?></button>

    </form>
    </div>

  </div>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/benjaminsparwasser/Desktop/gymapp/resources/views/auth/register.blade.php ENDPATH**/ ?>