<?php $__env->startSection('content'); ?>
  <div class="nutrition">
    <div class="nutrition__hero">
      <img loading="lazy" class="nutrition__image" src="<?php echo e($nutrition1->content_image); ?>" alt="">
      <h1 class="nutrition__title"><?php echo e($nutrition1->content_heading); ?></h1>
    </div>
  </div>
  <div class="nutrition bg-light">
  <div class="container ">
    <div class="nutrition__description">
      <div class="row justify-content-md-center">
        <div class="col-lg-8 col-lg-auto d-flex flex-column justify-content-center  align-items-center">
          <div class="nutrition__heading">
            <h1><?php echo e($nutrition2->content_heading); ?></h1>
          </div>
          <p><?php echo e($nutrition2->content_p); ?></p>
        </div>
      </div>
      
    </div>
      <div class="row ">
        <div class="col-lg-6">
          <div class="nutrition__box d-flex flex-column justify-content-center  align-items-center">
            <h3><?php echo e($nutrition3->content_heading); ?></h3>
            <p><?php echo e($nutrition3->content_p); ?></p>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="nutrition__box">
          <img loading="lazy" src="<?php echo e($nutrition3->content_image); ?>" class="col-12" alt="">
          </div>
        </div>
      </div>
      <div class="nutrition__section">
        <div class="row">
        <div class="col-lg-6">
          <div class="nutrition__box">
          <img loading="lazy" src="<?php echo e($nutrition4->content_image); ?>" class="col-12" alt="">
          </div>
        </div>
        <div class="col-lg-6">
          <div class="nutrition__box d-flex flex-column justify-content-center  align-items-center">
            <h3><?php echo e($nutrition4->content_heading); ?></h3>
            <p><?php echo e($nutrition4->content_p); ?></p>
          </div>
        </div>
      </div>
      </div>
      <div class="nutrition__section">
      <div class="row ">
        <div class="col-lg-6">
          <div class="nutrition__box d-flex flex-column justify-content-center  align-items-center">
            <h3><?php echo e($nutrition5->content_heading); ?></h3>
            <p><?php echo e($nutrition5->content_p); ?></p>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="nutrition__box">
          <img loading="lazy" src="<?php echo e($nutrition5->content_image); ?>" class="col-12" alt="">
          </div>
        </div>
      </div>
      </div>
      <div class="row ">
        <div class="col-lg-6">
          <div class="nutrition__box">
          <img loading="lazy" src="<?php echo e($nutrition6->content_image); ?>" class="col-12" alt="">
          </div>
        </div>
        <div class="col-lg-6">
          <div class="nutrition__box d-flex flex-column justify-content-center  align-items-center">
            <h3><?php echo e($nutrition6->content_heading); ?></h3>
            <p><?php echo e($nutrition6->content_p); ?></p>
          </div>
        </div>
      </div>
      <div class="nutrition__description">
      <div class="row justify-content-md-center">
      </div>
      
    </div>
    </div>
</div>


  <?php echo $__env->make('components.social-media', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/benjaminsparwasser/Desktop/gymapp/resources/views/pages/nutrition.blade.php ENDPATH**/ ?>