<?php $__env->startSection('content'); ?>
    <div class="container">
    <div class="row">
        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 mb-4">
            <div class="card">
                <h5 class="card-header">Edit A Plan One Benefit</h5>
                <div class="card-body">
            <form method="POST" action="/admin/all-plan-one/<?php echo e($benefitsOne->id); ?>">
                <?php echo csrf_field(); ?>
                
                <div class="form-group py-2">
                    <label for="inputbenefit">Benefit</label>
                    <input id="inputcourseimg" type="text" class="form-control " name="benefit" value="<?php echo e(old('benefit', $benefitsOne->benefit)); ?>"  autofocus placeholder="Benefit">
                </div>
                <div class="form-group py-2">
                    <label for="inputicon">Icon</label>
                    <select name="icon" id="icon">
                      <option value="fa-check">Check</option>
                      <option value="fa-x">X</option>
                    </select>
                </div>
                <div class="row">
                    <div class="col-sm-6 pb-2 pb-sm-4 pb-lg-0 pr-0">
                        <button type="submit" class="btn btn-space btn-primary mt-3">Submit</button>
                    </div>
                    <div class="col-sm-6 pl-0">
                        <p class="text-right">
                        </p>
                    </div>
                </div>
            </form>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/benjaminsparwasser/Desktop/gymapp/resources/views/admin/plan-one-edit.blade.php ENDPATH**/ ?>