<?php $__env->startSection('content'); ?>
  <div class="login">
   <div class="container">
    <form class="col-lg-4 mx-auto" method="POST" action="<?php echo e(route('login')); ?>">
      <?php echo csrf_field(); ?> 
      <h3 class="mb-3">Login</h3>
      <div class="mx-auto mb-3">
        <label class="form-label" for="" :value="__('Email')">Email</label>
        <input class="form-control" id="email" type="email" name="email" :value="old('email')" required autofocus>
      </div>
      <div class="mx-auto mb-3">
        <label class="form-label" for="password" :value="__('Password')">Password</label>
        <input id="password" class="form-control" type="password"
        name="password"
        required autocomplete="current-password">
      </div>
      <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="remember_me" name="remember">
    <label class="form-check-label" for="remember_me"><?php echo e(__('Remember me')); ?></label>
  </div>
  <button class="btn btn-primary mb-2" type="submit"><?php echo e(__('Log in')); ?></button>
    <?php if(Route::has('password.request')): ?>

    <a class="mt-3 login__link" href="<?php echo e(route('register')); ?>">
        <?php echo e(__('Register')); ?>

    </a>
    <a class="mt-3 login__link" href="<?php echo e(route('password.request')); ?>">
        <?php echo e(__('Forgot your password?')); ?>

    </a>
    
    <?php endif; ?>
    </form>
    </div>

  </div>
<?php $__env->stopSection(); ?>







<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/benjaminsparwasser/Desktop/gymapp/resources/views/auth/login.blade.php ENDPATH**/ ?>